The windows GDI renderer example is missing the following:

- Images
- Rendering Rounded Rectangle borders
- Custom Fonts (font size)
